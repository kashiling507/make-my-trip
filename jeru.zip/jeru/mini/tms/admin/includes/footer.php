<div class="copyrights">
	 <p>© 2022 TMS. All Rights Reserved |  <a href="#">KJR</a> </p>
</div>	
